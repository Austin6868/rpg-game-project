# Changelog
## [1.6.0-preview.4] - 2020-03-10
- [UX] Remove search provider sub categories. It simplifies the search view filter window.
- [UX] New scene provider filtering (added support for: id:<string>, path:<string/string> size:<number>, layer:<number>, tag:<string>, t:<type>, is:[visible|hidden|leaf|root|child])
- [UX] Add the ability to fetch items on a specific provider.
- [UX] Add support to override the default object picker using Quick Search
- [UX] Add support for multiple asset indexes.
- [UX] Add Search Engines for Unity's Search API.
- [UX] Add scene property filtering support (i.e. `t:light2d p(intensity)>=0.5`)
- [UX] Add grid view support to display search results in a grid of thumbnails.
- [UX] Add an embedded inspector for objects returned by the resource and scene search providers.
- [FIX] The asset store provider will only be available for 2020.1 and newer.
- [FIX] Support any characters in word searches.
- [FIX] Fix Unity crash when dragging and dropping from quick search (1215420)
- [FIX] Fix Quick Search fails to find assets when more than 16 characters are entered into the search field (1225947)
- [FIX] Fix Progress API usage.
- [FIX] Fix filter override application. Remove SearchFilter.
- [FIX] Fix complete file name indexing (case 1214270)
- [FIX] Fix actions sorting on SearchService init and in SearchSettings window.
- [FIX] Add better support for startup incremental update.
- [DOC] Quick Search 1.6 and higher will require Unity 2019.3 and higher.
- [API] You can now override the string comparison options for word/phrase matching with the `QueryEngine`.
- [API] Refactor SearchService to extract all the QuickSearch Window related stuff. Everything is driven by search context.
- [API] Optimize call to operator handlers when in fallback mode.
- [API] Multiple simultaneous calls to SearchService.GetItems can now be done with different search contexts.
- [API] Improved the build time of a QueryEngine search query.
- [API] Do not call onEnable/onDisable multiple time when doing multiple simultaneous searches with a provider.
- [API] Allow removal of filters on the QueryEngine.
- [API] Added the ability to customize a query engine with filters using method attributes. Used by the Scene Provider.

## [1.5.2] - 2020-02-18
- [FIX] Improve scene provider performances
- [FIX] Fix Unity crash when dragging and dropping from quick search (1215420)
- [Fix] Fix complete file name indexing (case 1214270)

## [1.5.1] - 2020-01-24
- [FIX] Fix Progress API usage.

## [1.5.0] - 2020-01-22
- [UX] You can now search scene objects with a given component using c:<component name>.
- [UX] We've removed the dockable window mode of Quick Search since it wasn't playing nice with some loading and refreshing workflows and optimizations.
- [UX] Update the quick search spinning wheel when async results are still being fetched.
- [UX] Select search item on mouse up instead of mouse down.
- [UX] fetchPreview of AssetStoreProvider uses the PurchaseInfo to get a bigger/more detailed preview.
- [UX] Change the Resources Provider to use the QueryEngine. Some behaviors may have changed.
- [UX] Asset Store provider fetches multiple screenshots and populates the preview panel carousel with those.
- [UX] Add UMPE quick search indexing to build the search index in another process.
- [UX] Add selected search item preview panel.
- [UX] Add Resource provider, which lets you search all resources loaded by Unity.
- [UX] Add new Unity 2020.1 property editor support.
- [UX] Add drag and drop support to the resource search provider.
- [UX] Add documentation link to Help provider and version label.
- [UX] Add Asset Store provider populating items with asset store package.
- [UX] Add a new settings to enable the new asset indexer in the user preferences.
- [UX] Add a new asset indexer that indexes many asset properties, such as dependencies, size, serialized properties, etc.
- [UX] Add a carrousel to display images of asset store search results.
- [FIX] Only enable the search asset watcher once the quick search tool is used the first time.
- [FIX] Do not load the LogProvider if the application console log path is not valid.
- [FIX] Add support for digits when splitting camel cases of file names.
- [FIX] Prevent search callback errors when not validating queries.
- [DOC] Quick Search Manual has been reviewed and edited.
- [DOC] Document more APIs.
- [DOC] Add some sample packages to Quick Search to distribute more search provider and query engine examples.
- [API] Make Unity.QuickSearch.QuickSearch public to allow user to open quick search explicitly with specific context data.
- [API] Improved the SearchIndexer API and performances
- [API] Change the signature of `fetchItems` to return an object instead of an `IEnumerable<SearchItem>`. This item can be an `IEnumerable<SearchItem>` as before, or an `IEnumerator` to allow yield returns of `IEnumerator` or `IEnumerable`.
- [API] Add the ability to configure string comparisons with the QueryEngine.
- [API] Add the `QueryEngine` API.
- [API] Add `QuickSearch.ShowWindow(float width, float height)` to allow opening Quick Search at any size.

## [1.4.1] - 2019-09-03
- Quick Search is now a verified package.
- [UX] Add UIElements experimental search provider.
- [FIX] Add to the asset search provider type filter all ScriptableObject types.
- [FIX] Fix Asset store URL.
- [DOC] Document more public APIs.
- [API] Add programming hooks to the scene search provider.
